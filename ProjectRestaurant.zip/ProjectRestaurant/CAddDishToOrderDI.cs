using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectRestaurant
{
    class CAddDishToOrderDI : ICommand
    {
        private OrderDineIn _order;
        private Dish _dish;
        public CAddDishToOrderDI(OrderDineIn order, Dish dish)
        {
            _order = order;
            _dish = dish;
        }
        public void Execute()
        {
            _order.AddDish(_dish);

        }
    }
}