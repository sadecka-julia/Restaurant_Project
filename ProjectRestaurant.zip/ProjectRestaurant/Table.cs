using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectRestaurant
{
    class Table
    {
        private int _tableID;
        private int _capacity;
        public Table(int tableID, int capacity)
        {
            _tableID = tableID;
            _capacity = capacity;
        }

    }
}