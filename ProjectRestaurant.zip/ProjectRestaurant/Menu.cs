using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectRestaurant
{
    class Menu
    {
        private List<Dish> _dishes = new List<Dish>();
        public void AddDish(Dish dish)
        {
            _dishes.Add(dish);
        }
    }
    
}