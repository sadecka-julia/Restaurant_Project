﻿namespace ProjectRestaurant
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Making Restaurant
            Menu menu = new Menu();
            Restaurant restaurant = new Restaurant("Szybko i Smacznie", "Majowa 6, Katowice", menu);
            Table table1 = new Table(1, 2);
            Table table2 = new Table(2, 2);
            Table table3 = new Table(3, 4);
            Table table4 = new Table(4, 3);
            Table table5 = new Table(5, 6);
            Table table6 = new Table(6, 5);

            // Adding Dishes to Menu
            Dish dish1 = new Dish(1, "Zupa pomidorowa", 9, 4);
            Dish dish2 = new Dish(2, "Rosół", 8, 5);
            Dish dish3 = new Dish(3, "Kotlet schabowy", 20, 7);
            Dish dish4 = new Dish(4, "Devoile", 15, 6);
            menu.AddDish(dish1);
            menu.AddDish(dish2);
            menu.AddDish(dish3);
            menu.AddDish(dish4);

            // Making Employees
            EChef chef1 = new EChef(1, "Adam", "Małysz", 4000, 30);
            EChef chef2 = new EChef(2, "Kamil", "Stoch", 4100, 35);
            EManager manager3 = new EManager(3, "Jakub", "Błaszczykowski", 7500, 40);
            EWaiter waiter4 = new EWaiter(4, "Iga", "Świątek", 3500, 30);
            EWaiter waiter5 = new EWaiter(5, "Justyna", "Święty", 4000, 35);
            
            // Making logic
            OrderService os = new OrderService();
            OrderDineIn order1 = new OrderDineIn(1, table1);
            

            Console.WriteLine("Who are you: waiter [1]");
            string position = Console.ReadLine();

            if(position == "1")
            {
                bool running = true;
                while (running)
                {
                    Console.WriteLine("What you want to do?");
                    Console.WriteLine("[1] Add dish to order");
                    Console.WriteLine("[2] Remove dish from order");
                    Console.WriteLine("[3] Quit");

                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            Console.WriteLine("OrderID: ");
                            string orderID = Console.ReadLine();
                            Console.WriteLine("DishID: ");
                            string dishID = Console.ReadLine();

                            // Tworzenie konkretnego polecenia
                            CAddDishToOrderDI add = new CAddDishToOrderDI(order1, dish1);

                            // Dodawanie polecenia do invokera
                            os.AddCommand(add);

                            Console.WriteLine($"Danie '{dishID}' zostało dodane do zamówienia.");
                            break;

                        case "2":
                            // Tworzenie konkretnego polecenia
                            CRemoveDishFromOrderDI remove = new CRemoveDishFromOrderDI(order1, dish1);

                            // Dodawanie polecenia do invokera
                            os.AddCommand(remove);

                            Console.WriteLine("Zamówienie zostało usunięte.");
                            break;

                        case "3":
                            running = false;
                            break;

                        default:
                            Console.WriteLine("Nieprawidłowy wybór.");
                            break;
                    }

                    // Wykonanie zgromadzonych poleceń
                    os.MakeCommands();
                    Console.WriteLine();
                }
            }

        }

    }
}