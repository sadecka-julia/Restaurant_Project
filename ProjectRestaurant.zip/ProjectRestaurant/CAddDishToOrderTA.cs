using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectRestaurant
{
    class CAddDishToOrderTA : ICommand
    {
        private OrderTakeAway _order;
        private Dish _dish;
        public CAddDishToOrderTA(OrderTakeAway order, Dish dish)
        {
            _order = order;
            _dish = dish;
        }
        public void Execute()
        {
            _order.AddDish(_dish);

        }
    }
}