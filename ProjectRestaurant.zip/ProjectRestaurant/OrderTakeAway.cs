using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectRestaurant
{
    class OrderTakeAway : IOrder
    {
        private int _orderID;
        private string _hoursOfTake;
        private List<Dish> _dishes = new List<Dish>();
        private float _sum;
        public OrderTakeAway(int orderID, string hoursOfTake)
        {
            _orderID = orderID;
            _hoursOfTake = hoursOfTake;
        }
        public void TakeOrder()
        {
            
        }
        public void AddDish(Dish dish)
        {
            _dishes.Add(dish);
            Console.WriteLine($"Add '{dish.Name}' to order {_orderID}");
        }
        public void RemoveDish(Dish dish)
        {
            _dishes.Remove(dish);
            Console.WriteLine($"Remove '{dish.Name}' from order {_orderID}");
        }
    }
}