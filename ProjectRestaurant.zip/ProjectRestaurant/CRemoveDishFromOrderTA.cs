using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectRestaurant
{
    class CRemoveDishFromOrderTA : ICommand
    {
        private OrderTakeAway _order;
        private Dish _dish;
        public CRemoveDishFromOrderTA(OrderTakeAway order, Dish dish)
        {
            _order = order;
            _dish = dish;
        }
        public void Execute()
        {
            _order.AddDish(_dish);
        }
    }
}